#include <stdio.h>
#include <stdlib.h>
#include <immintrin.h>
const char* dgemm_desc = "Simple blocked dgemm.";

#ifndef BLOCK_SIZE
#define BLOCK_SIZE 4

// Theoretical
// #define BLOCK_SIZE_1 148
// #define BLOCK_SIZE_2 37

#define BLOCK_SIZE_1 32
#define BLOCK_SIZE_2 4
#endif

#define min(a, b) (((a) < (b)) ? (a) : (b))

// /*
//   5. AVX
// */
static void do_block_2(int lda, int M2, int N2, int K2, double* A, double* B, double* C) {
    // For each row i of A
    for (int i = 0; i < M2; ++i) {
        // For each column j of B
        for (int j = 0; j < N2; ++j) {
            // Compute C(i,j)
            double cij = C[i + j * lda];
            for (int k = 0; k < K2; ++k) {
                cij += A[k + i * lda] * B[k + j * lda];
            }
            C[i + j * lda] = cij;
        }
    }
}

static void micro_kernel(int lda, int M2, int N2, int K2, double* A, double* B, double* C) {
    __m256d Ar;
    __m256d Br;
    __m256d Cr;

    for(int i=0; i<M2; i++){
        for(int j=0; j<N2; j++){
            Cr = _mm256_loadu_pd(C + i + j*lda);
            for(int k=0; k<K2; k++){
                Ar = _mm256_broadcast_sd(A + k + i*lda);
                Br = _mm256_loadu_pd(B + k + j * lda);
                Cr = _mm256_add_pd(Cr, _mm256_mul_pd(Ar, Br));
            }
            _mm256_store_pd(C + i + j*lda, Cr);
        }
    }
}

static void do_block_1(int lda, int M1, int N1, int K1, double* A, double* B, double* C) {
    // For each block-row of A
    for (int i = 0; i < M1; i += BLOCK_SIZE_2) {
        // For each block-column of B
        for (int j = 0; j < N1; j += BLOCK_SIZE_2) {   
            // Accumulate block dgemms into block of C
            for (int k = 0; k < K1; k += BLOCK_SIZE_2) {
                // Perform individual block dgemm
                int M2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - i);
                int N2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - j);
                int K2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - k);
                micro_kernel(lda, M2, N2, K2, A + k + i * lda, B + k + j * lda, C + i + j * lda);
            }
        }
    }
}

void square_dgemm(int lda, double* A, double* B, double* C) {
    double* rA =  _mm_malloc(lda*lda*sizeof(double), 64);
    for(int i=0; i<lda; i++){
        for(int j=0; j<lda; j++){
            rA[j + i*lda] = A[i + j*lda];
        }
    }
    // For each block-row of A
    for (int i = 0; i < lda; i += BLOCK_SIZE_1) {
        // For each block-column of B
        for (int j = 0; j < lda; j += BLOCK_SIZE_1) {
            // Accumulate block dgemms into block of C
            for (int k = 0; k < lda; k += BLOCK_SIZE_1) {
                // Correct block dimensions if block "goes off edge of" the matrix
                int M1 = min(BLOCK_SIZE_1, lda - i);
                int N1 = min(BLOCK_SIZE_1, lda - j);
                int K1 = min(BLOCK_SIZE_1, lda - k);
                // Perform individual block dgemm
                if((M1 <= BLOCK_SIZE_1)||(N1 <= BLOCK_SIZE_1)||(K1 <= BLOCK_SIZE_1)){
                    do_block_2(lda, M1, N1, K1, rA + k + i * lda, B + k + j * lda, C + i + j * lda);
                }else{
                    do_block_1(lda, M1, N1, K1, rA + k + i * lda, B + k + j * lda, C + i + j * lda);
                }
            }
        }
    }
}

/*
  1. Blocking
*/
// static void do_block(int lda, int M, int N, int K, double* A, double* B, double* C) {
//     // For each row i of A
//     for (int i = 0; i < M; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K; ++k) {
//                 cij += A[i + k * lda] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE) {
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < lda; k += BLOCK_SIZE) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M = min(BLOCK_SIZE, lda - i);
//                 int N = min(BLOCK_SIZE, lda - j);
//                 int K = min(BLOCK_SIZE, lda - k);
//                 // Perform individual block dgemm
//                 do_block(lda, M, N, K, A + i + k * lda, B + k + j * lda, C + i + j * lda);
//             }
//         }
//     }
// }

/*
  2.Multi-level block + repack
*/
// static void do_block_2(int lda, int M2, int N2, int K2, double* A, double* B, double* C) {
//     // For each row i of A
//     for (int i = 0; i < M2; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N2; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K2; ++k) {
//                 cij += A[i + k * lda] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//     }
// }

// static void do_block_1(int lda, int M1, int N1, int K1, double* A, double* B, double* C) {
//     // For each block-row of A
//     for (int i = 0; i < M1; i += BLOCK_SIZE_2) {
//         // For each block-column of B
//         for (int j = 0; j < N1; j += BLOCK_SIZE_2) {   
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < K1; k += BLOCK_SIZE_2) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - i);
//                 int N2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - j);
//                 int K2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - k);
//                 // Perform individual block dgemm
//                 do_block_2(lda, M2, N2, K2, A + i + k * lda, B + k + j * lda, C + i + j * lda);
//             }
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE_1) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE_1) {
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < lda; k += BLOCK_SIZE_1) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M1 = min(BLOCK_SIZE_1, lda - i);
//                 int N1 = min(BLOCK_SIZE_1, lda - j);
//                 int K1 = min(BLOCK_SIZE_1, lda - k);
//                 // Perform individual block dgemm
//                 if((M1 <= BLOCK_SIZE_1)||(N1 <= BLOCK_SIZE_1)||(K1 <= BLOCK_SIZE_1)){
//                     do_block_2(lda, M1, N1, K1, A + i + k * lda, B + k + j * lda, C + i + j * lda);
//                 }else{
//                     do_block_1(lda, M1, N1, K1, A + i + k * lda, B + k + j * lda, C + i + j * lda);
//                 }
//             }
//         }
//     }
// }

/*
  3.Repack and realign
*/
// repack

// void square_dgemm(int n, double* A, double* B, double* C) {
//     double* rA = (double*)malloc(n*n*sizeof(double));

//     for(int i=0; i<n; i++){
//         for(int j=0; j<n; j++){
//             rA[j + i*n] = A[i + j*n];
//         }
//     }
//     // For each row i of A
//     for (int i = 0; i < n; ++i) {
//         // For each column j of B
//         for (int j = 0; j < n; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j*n];
//             for (int k = 0; k < n; k++) {
//                 cij += rA[k + i*n] * B[k + j*n];
//             }
//             C[i + j*n] = cij;
//         }
//     }
// }

// repack2
// static void do_block(int lda, int M, int N, int K, double* A, double* B, double* C) {
//     // For each row i of A
//     int pointer = 0;
//     for (int i = 0; i < M; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K; ++k) {
//                 cij += A[k + pointer] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//         pointer += K;
//     }
// }

// static void assign_block(int lda, int M, int N, double *rA, double *A){
//     int count = 0;
//     for(int i=0; i<M; i++){
//         for(int j=0; j<N; j++){
//             rA[count] = A[i + j*lda];
//             count++;
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     double* rA =  _mm_malloc(lda*lda*sizeof(double), 64);
//     int pointer = 0;
//     for(int i=0; i<lda; i+=BLOCK_SIZE){
//         for(int j=0; j<lda; j+=BLOCK_SIZE){
//             int M = min(BLOCK_SIZE, lda - i);
//             int N = min(BLOCK_SIZE, lda - j);
//             assign_block(lda, M, N, rA+pointer, A+i+j*lda);
//             pointer += M*N;
//         }
//     }

//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE) {
//             // Accumulate block dgemms into block of C
//             pointer = i*lda;
//             for (int k = 0; k < lda; k += BLOCK_SIZE) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M = min(BLOCK_SIZE, lda - i);
//                 int N = min(BLOCK_SIZE, lda - j);
//                 int K = min(BLOCK_SIZE, lda - k);
//                 // Perform individual block dgemm
//                 do_block(lda, M, N, K, rA + pointer, B + k + j * lda, C + i + j * lda);
//                 pointer += M*K;
//             }
//         }
//     }
// }

// repack2 + multi
// static void do_block_2(int lda, int M2, int N2, int K2, double* A, double* B, double* C) {
//     // For each row i of A
//     int pointer = 0;
//     for (int i = 0; i < M2; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N2; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K2; ++k) {
//                 cij += A[k + pointer] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//         pointer += K2;
//     }
// }

// static void do_block_1(int lda, int M1, int N1, int K1, double* A, double* B, double* C) {
//     // For each block-row of A
//     for (int i = 0; i < M1; i += BLOCK_SIZE_2) {
//         // For each block-column of B
//         for (int j = 0; j < N1; j += BLOCK_SIZE_2) {   
//             // Accumulate block dgemms into block of C
//             int pointer = i*lda;
//             for (int k = 0; k < K1; k += BLOCK_SIZE_2) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - i);
//                 int N2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - j);
//                 int K2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - k);
//                 // Perform individual block dgemm
//                 do_block_2(lda, M2, N2, K2, A + pointer, B + k + j * lda, C + i + j * lda);
//             }
//         }
//     }
// }

// static void assign_block(int lda, int M, int N, double *rA, double *A){
//     int count = 0;
//     for(int i=0; i<M; i++){
//         for(int j=0; j<N; j++){
//             rA[count] = A[i + j*lda];
//             count++;
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     double* rA =  _mm_malloc(lda*lda*sizeof(double), 64);
//     int pointer = 0;
//     for(int i=0; i<lda; i+=BLOCK_SIZE_1){
//         for(int j=0; j<lda; j+=BLOCK_SIZE_1){
//             int M = min(BLOCK_SIZE_1, lda - i);
//             int N = min(BLOCK_SIZE_1, lda - j);
//             assign_block(lda, M, N, rA+pointer, A+i+j*lda);
//             pointer += M*N;
//         }
//     }
//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE_1) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE_1) {
//             // Accumulate block dgemms into block of C
//             pointer = i*lda;
//             for (int k = 0; k < lda; k += BLOCK_SIZE_1) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M1 = min(BLOCK_SIZE_1, lda - i);
//                 int N1 = min(BLOCK_SIZE_1, lda - j);
//                 int K1 = min(BLOCK_SIZE_1, lda - k);
//                 // Perform individual block dgemm
//                 if((M1 <= BLOCK_SIZE_1)||(N1 <= BLOCK_SIZE_1)||(K1 <= BLOCK_SIZE_1)){
//                     do_block_2(lda, M1, N1, K1, rA + pointer, B + k + j * lda, C + i + j * lda);
//                 }else{
//                     do_block_1(lda, M1, N1, K1, rA + pointer, B + k + j * lda, C + i + j * lda);
//                 }
//             }
//         }
//     }
// }

// /*
//   4. Change order of i, j, k
// */
// void square_dgemm(int n, double* A, double* B, double* C) {
//     double* rA = (double*)malloc(n*n*sizeof(double));
//     double* rB = (double*)malloc(n*n*sizeof(double));
//     for(int i=0; i<n; i++){
//         for(int j=0; j<n; j++){
//             rA[j + i*n] = A[i + j*n];
//             rB[i + j*n] = B[j + i*n];
//         }
//     }

//     for (int i = 0; i < n; ++i) {
//         for(int k=0; k<n; k++){
//             double aik = A[k + i*n];
//             for(int j=0; j<n; j++){
//                 C[j + i*n] += aik * B[j + k*n];
//             }
//         }
//     }
// }

//////////////////////////
// block + repack + change order
// static void do_block(int lda, int M, int N, int K, double* A, double* B, double* C) {
//     // For each row i of A
//     for (int i = 0; i < M; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K; ++k) {
//                 cij += A[k + i * lda] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     double* rA =  _mm_malloc(lda*lda*sizeof(double), 64);
//     for(int i=0; i<lda; i++){
//         for(int j=0; j<lda; j++){
//             rA[j + i*lda] = A[i + j*lda];
//         }
//     }
//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE) {
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < lda; k += BLOCK_SIZE) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M = min(BLOCK_SIZE, lda - i);
//                 int N = min(BLOCK_SIZE, lda - j);
//                 int K = min(BLOCK_SIZE, lda - k);
//                 // Perform individual block dgemm
//                 do_block(lda, M, N, K, rA + k + i * lda, B + k + j * lda, C + i + j * lda);
//             }
//         }
//     }
// }


/*
  2.Multi-level block + reorder
*/
// static void do_block_2(int lda, int M2, int N2, int K2, double* A, double* B, double* C) {
//     // For each row i of A
//     for (int i = 0; i < M2; ++i) {
//         // For each column j of B
//         for (int j = 0; j < N2; ++j) {
//             // Compute C(i,j)
//             double cij = C[i + j * lda];
//             for (int k = 0; k < K2; ++k) {
//                 cij += A[k + i * lda] * B[k + j * lda];
//             }
//             C[i + j * lda] = cij;
//         }
//     }
// }

// static void do_block_1(int lda, int M1, int N1, int K1, double* A, double* B, double* C) {
//     // For each block-row of A
//     for (int i = 0; i < M1; i += BLOCK_SIZE_2) {
//         // For each block-column of B
//         for (int j = 0; j < N1; j += BLOCK_SIZE_2) {   
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < K1; k += BLOCK_SIZE_2) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - i);
//                 int N2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - j);
//                 int K2 = min(BLOCK_SIZE_2, BLOCK_SIZE_1 - k);
//                 // Perform individual block dgemm
//                 do_block_2(lda, M2, N2, K2, A + k + i * lda, B + k + j * lda, C + i + j * lda);
//             }
//         }
//     }
// }

// void square_dgemm(int lda, double* A, double* B, double* C) {
//     double* rA =  _mm_malloc(lda*lda*sizeof(double), 64);
//     for(int i=0; i<lda; i++){
//         for(int j=0; j<lda; j++){
//             rA[j + i*lda] = A[i + j*lda];
//         }
//     }
//     // For each block-row of A
//     for (int i = 0; i < lda; i += BLOCK_SIZE_1) {
//         // For each block-column of B
//         for (int j = 0; j < lda; j += BLOCK_SIZE_1) {
//             // Accumulate block dgemms into block of C
//             for (int k = 0; k < lda; k += BLOCK_SIZE_1) {
//                 // Correct block dimensions if block "goes off edge of" the matrix
//                 int M1 = min(BLOCK_SIZE_1, lda - i);
//                 int N1 = min(BLOCK_SIZE_1, lda - j);
//                 int K1 = min(BLOCK_SIZE_1, lda - k);
//                 // Perform individual block dgemm
//                 if((M1 <= BLOCK_SIZE_1)||(N1 <= BLOCK_SIZE_1)||(K1 <= BLOCK_SIZE_1)){
//                     do_block_2(lda, M1, N1, K1, rA + k + i * lda, B + k + j * lda, C + i + j * lda);
//                 }else{
//                     do_block_1(lda, M1, N1, K1, rA + k + i * lda, B + k + j * lda, C + i + j * lda);
//                 }
//             }
//         }
//     }
// }